# ilabcollab -- Version 6
Current working url: http://tiny.cc/ilabcollab


***Upcoming***:
1. persistent data between server restarts. <--done in V6
2. Cards implementation for collab space. (along with realtime sharing and MEMEs)
3. One Page for all the rooms (No reloads for room change)
4. Timestamp for messages.
5. Different DB for development.

**version 6** -->
1. Messages' persistence now resistant to server restarts !! WOW.
2. Dropdown available for room login screen

**version 5** -->
1. Spaces in chat room's names are now allowed

**version 4.1** -->
1. First working version. changed chat keyword to collab.
2. new room names with spaces crashes the system :(