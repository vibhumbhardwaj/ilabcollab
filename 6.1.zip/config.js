module.exports = {
    connectionString : 'mongodb://vibhum:hellothere@ds032887.mlab.com:32887/dbone',
    mongoIdRegex: /^[A-Za-z0-9]{24}$/,
    alphaNumericRegex: /^[a-zA-Z0-9_]{1,}$/,
    searchQueryRegex: /^[a-zA-z0-9 _@#]{1,}$/,
    secretKey : 'I am the secret key madafakaa.',
    ImageAPIKey: '11a457f48752418ab1b8b21ff727aba9'
}